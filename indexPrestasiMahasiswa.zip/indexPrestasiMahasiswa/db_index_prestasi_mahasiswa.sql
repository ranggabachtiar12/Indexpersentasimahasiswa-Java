
DROP TABLE IF EXISTS `data_prestasi`;
CREATE TABLE IF NOT EXISTS `data_prestasi` (
  `nim`   varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `prodi`        varchar(50) NOT NULL,
  `ip`        float NOT NULL,
  `email`        varchar(50) NOT NULL,
  `telp`        varchar(20) NOT NULL,
  PRIMARY KEY (`nim`)
);

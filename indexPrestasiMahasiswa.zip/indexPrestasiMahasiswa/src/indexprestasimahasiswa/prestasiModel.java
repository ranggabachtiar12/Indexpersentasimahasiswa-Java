package indexprestasimahasiswa;

import com.mysql.jdbc.exceptions.jdbc4.CommunicationsException;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class prestasiModel {

    protected final String URL_WITH_DB = "jdbc:mysql://localhost:3306/db_index_prestasi_mahasiswa";
    protected final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    protected Statement stmt = null;
    protected Connection conn = null;
    protected PreparedStatement preparedStmt;
    protected ResultSet rs;

    protected final String username = "root";
    protected final String password = "";
    protected String query = null;

    protected void notifErrorTryCatch(Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null,
                "Pesan       : " + e.getMessage() + "\n",
                "Error!",
                JOptionPane.ERROR_MESSAGE,
                null
        );
    }

    public void insertPegawai(String nim, String nama, String prodi, float ip, String email, String telp) {
        try {
            Class.forName(JDBC_DRIVER);
            conn = DriverManager.getConnection(URL_WITH_DB, username, password);

            query = " insert into data_prestasi ("
                    + "nim, "
                    + "nama, "
                    + "prodi, "
                    + "ip, "
                    + "email, "
                    + "telp) "
                    + " values (?, ?, ?, ?, ?, ?)";

            preparedStmt = conn.prepareStatement(query);

            preparedStmt.setString(1, nim);
            preparedStmt.setString(2, nama);
            preparedStmt.setString(3, prodi);
            preparedStmt.setFloat(4, ip);
            preparedStmt.setString(5, email);
            preparedStmt.setString(6, telp);

            preparedStmt.execute();

            preparedStmt.close();
            conn.close();

            JOptionPane.showMessageDialog(null, "Berhasil menyimpan data");
        } catch (ClassNotFoundException | SQLException e) {
            notifErrorTryCatch(e);
        }
    }

    
    public void updatePegawai(String nim, String nama, String prodi, float ip, String email, String telp) {
        try {
            Class.forName(JDBC_DRIVER);
            conn = DriverManager.getConnection(URL_WITH_DB, username, password);

            query = " UPDATE data_prestasi SET "
                    
                    + " nama = \""+ nama +"\", "
                    + " prodi = \""+ prodi +"\", "
                    + " ip = "+ ip +", "
                    + " email = \""+ email +"\", "
                    + " telp = \""+ telp +"\" "
                    
                    + " WHERE nim = \""+ nim +"\"";

            preparedStmt = conn.prepareStatement(query);

            preparedStmt.execute();

            preparedStmt.close();
            conn.close();

            JOptionPane.showMessageDialog(null, "Berhasil merubah data");
        } catch (ClassNotFoundException | SQLException e) {
            notifErrorTryCatch(e);
        }
    }

    public void deletePegawai(String nama) {
        try {
            Class.forName(JDBC_DRIVER);
            conn = DriverManager.getConnection(URL_WITH_DB, username, password);

            query = "DELETE FROM data_prestasi "
                    + " WHERE nama = \""+ nama +"\"";

            preparedStmt = conn.prepareStatement(query);

            preparedStmt.execute();

            preparedStmt.close();
            conn.close();

            JOptionPane.showMessageDialog(null, "Berhasil menghapus data");
        } catch (ClassNotFoundException | SQLException e) {
            notifErrorTryCatch(e);
        }
    }

    public void tambahComboBoxNamaPegawai(JComboBox comboBoxNamaPegawai) {
        comboBoxNamaPegawai.removeAllItems();
        try{
            Class.forName(JDBC_DRIVER);  
            conn = DriverManager.getConnection(URL_WITH_DB, username, password);
            
            stmt = conn.createStatement(); 
            query = " SELECT `nama`\n" +
                    " FROM `data_pegawai`";
            rs = stmt.executeQuery(query);

            while (rs.next()){
                comboBoxNamaPegawai.addItem(rs.getString("nama"));
            }
            rs.close();
            stmt.close();
            conn.close();
            
        } catch(CommunicationsException e) {
            notifErrorTryCatch(e);
        } catch (ClassNotFoundException | SQLException e) {
            notifErrorTryCatch(e);
        }
    }

    
    public void setTableValues(JTable tabel, String query) {
        DefaultTableModel tabelModel = new DefaultTableModel();
        tabelModel.addColumn("NIM");
        tabelModel.addColumn("NAMA");
        tabelModel.addColumn("PRODI");
        tabelModel.addColumn("IP");
        tabelModel.addColumn("EMAIL");
        tabelModel.addColumn("TELP");
        try{
            Class.forName(JDBC_DRIVER);  
            conn = DriverManager.getConnection(URL_WITH_DB, username, password);
            
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            while(rs.next()) {
                tabelModel.addRow(new Object[]{
                    rs.getString("nim"),
                    rs.getString("nama"),
                    rs.getString("prodi"),
                    rs.getString("ip"),
                    rs.getString("email"),
                    rs.getString("telp")
                });
                
            } // end while
            tabel.setModel(tabelModel);
            rs.close();
            stmt.close();
            conn.close();
        } catch(HeadlessException | ClassNotFoundException | SQLException e){
            notifErrorTryCatch(e);
        }
    }
}
